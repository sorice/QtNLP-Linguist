var annotated =
[
    [ "Cargando", "class_cargando.html", "class_cargando" ],
    [ "Comando", "struct_comando.html", "struct_comando" ],
    [ "dlbrillo", "classdlbrillo.html", "classdlbrillo" ],
    [ "dlcontraste", "classdlcontraste.html", "classdlcontraste" ],
    [ "Dlg_Balancear_colores", "class_dlg___balancear__colores.html", "class_dlg___balancear__colores" ],
    [ "Dlg_Escala_grises", "class_dlg___escala__grises.html", "class_dlg___escala__grises" ],
    [ "Dlg_Escalar", "class_dlg___escalar.html", "class_dlg___escalar" ],
    [ "Dlg_Gamma", "class_dlg___gamma.html", "class_dlg___gamma" ],
    [ "Dlg_modificar_color", "class_dlg__modificar__color.html", "class_dlg__modificar__color" ],
    [ "DlgTransformar", "class_dlg_transformar.html", "class_dlg_transformar" ],
    [ "ImageThumbnail", "class_image_thumbnail.html", "class_image_thumbnail" ],
    [ "ListaDeComandos", "class_lista_de_comandos.html", "class_lista_de_comandos" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ]
];