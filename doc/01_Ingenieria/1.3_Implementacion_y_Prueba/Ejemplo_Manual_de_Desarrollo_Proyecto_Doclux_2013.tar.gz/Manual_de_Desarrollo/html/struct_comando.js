var struct_comando =
[
    [ "Comando", "struct_comando.html#a604b29b29f590c08b7f6ef5121e39fa8", null ],
    [ "comando", "struct_comando.html#a7cb56e779d18ea01914f432e8f7e8656", null ],
    [ "parametros", "struct_comando.html#aee184567e726030def5f83a67d770d52", null ]
];