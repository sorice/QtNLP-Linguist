var class_dlg___gamma =
[
    [ "Dlg_Gamma", "class_dlg___gamma.html#a8316ccd199b9e156f4c95c4ee9639021", null ],
    [ "~Dlg_Gamma", "class_dlg___gamma.html#ad20bc212e293d019778022c7bf4aaa0b", null ],
    [ "closeEvent", "class_dlg___gamma.html#aeccf2e0adb81e5124d1077248947751c", null ],
    [ "fin_procesamiento", "class_dlg___gamma.html#abdf43a99acaf5dc21cebd7a3d0f32e9a", null ],
    [ "inicio_procesamiento", "class_dlg___gamma.html#a2e7e80635752cbd49bf3228535f9a94d", null ],
    [ "on_btn_todas_clicked", "class_dlg___gamma.html#aba006b11834aa63e26e5f04a1524352b", null ],
    [ "on_pushButton_clicked", "class_dlg___gamma.html#a3d84fc897bed3c4012179cec7a3f887e", null ],
    [ "ui", "class_dlg___gamma.html#a0b6ab6e9407a493f407e620f07d68b77", null ]
];