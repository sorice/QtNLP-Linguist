var classdlbrillo =
[
    [ "dlbrillo", "classdlbrillo.html#aab7c85a7534542a4421adc492d5a9a87", null ],
    [ "~dlbrillo", "classdlbrillo.html#a0c5fdc1ac49b6b324200369bd84b0c71", null ],
    [ "closeEvent", "classdlbrillo.html#a1f787ae03bb3a02c816d61bb3b5e99df", null ],
    [ "fin_procesamiento", "classdlbrillo.html#adeeb18cc872864498f8f81a6df888f30", null ],
    [ "inicio_procesamiento", "classdlbrillo.html#aa925751da32b92232c311180cce6549c", null ],
    [ "on_automatico_clicked", "classdlbrillo.html#a99f37ef1648976b4eb9549596da71e6b", null ],
    [ "on_btn_actual_clicked", "classdlbrillo.html#a91a1213cffe10558776cbfe356950c0a", null ],
    [ "on_btn_todas_clicked", "classdlbrillo.html#a84f1f1fc7a0154b0d7e839183d49348e", null ],
    [ "on_manual_clicked", "classdlbrillo.html#a39f6658d2e5b7df8be4c600a74ee4fa7", null ],
    [ "ui", "classdlbrillo.html#a842fa5bf7e25dd79f5264a58b14ec68c", null ]
];