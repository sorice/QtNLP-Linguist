var class_dlg___escalar =
[
    [ "Dlg_Escalar", "class_dlg___escalar.html#a536abc43593595d25567f3bc9c192c7d", null ],
    [ "~Dlg_Escalar", "class_dlg___escalar.html#a7bb22292d62226899669ea23aa33a11f", null ],
    [ "closeEvent", "class_dlg___escalar.html#af273e0eb45d2323a8facb43fbecb4cfb", null ],
    [ "fin_procesamiento", "class_dlg___escalar.html#a1aba4f60a132dc444038864bd49fad05", null ],
    [ "inicio_procesamiento", "class_dlg___escalar.html#a0982e6576a71b5fac4b6649690c43d09", null ],
    [ "on_btn_todas_clicked", "class_dlg___escalar.html#a26d78a3a03863ac9bd1d13cb1574863d", null ],
    [ "on_pushButton_clicked", "class_dlg___escalar.html#a58b1ddab2e07435c8077a289752b3fd1", null ],
    [ "ui", "class_dlg___escalar.html#a81f4dc8edd42a176b3dd6150f71321ce", null ]
];