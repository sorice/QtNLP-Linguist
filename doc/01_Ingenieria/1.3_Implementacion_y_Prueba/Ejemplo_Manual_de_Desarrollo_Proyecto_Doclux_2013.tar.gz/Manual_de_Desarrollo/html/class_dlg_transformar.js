var class_dlg_transformar =
[
    [ "DlgTransformar", "class_dlg_transformar.html#a8b8b32097987ed1c32020dcb00d16ec4", null ],
    [ "~DlgTransformar", "class_dlg_transformar.html#aa12a1cd89920f21f53f2bdb2eb4cb488", null ],
    [ "on_pushButton_clicked", "class_dlg_transformar.html#aeb86f04d8f63974148836bfa8604d21c", null ],
    [ "ui", "class_dlg_transformar.html#a7c475f009a30a9c15720e65b2b617b1e", null ]
];