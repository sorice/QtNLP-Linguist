var class_dlg___escala__grises =
[
    [ "Dlg_Escala_grises", "class_dlg___escala__grises.html#a10ac7be520d66e895588b598dec188ec", null ],
    [ "~Dlg_Escala_grises", "class_dlg___escala__grises.html#aaf30e7cdce5cd360d21ab0a5318c18cb", null ],
    [ "closeEvent", "class_dlg___escala__grises.html#aa7f97c17eb97d10b07ad617296822777", null ],
    [ "fin_procesamiento", "class_dlg___escala__grises.html#a03c6b24ee9224a5e10383df956d99a7a", null ],
    [ "inicio_procesamiento", "class_dlg___escala__grises.html#a35abdbcf0b9c0bb50a9139099eb4847c", null ],
    [ "on_btn_todas_clicked", "class_dlg___escala__grises.html#a62516c10a5285bb10737e42166ff2a9a", null ],
    [ "on_pushButton_3_clicked", "class_dlg___escala__grises.html#aab70e7ba1cddfbc8f36399e67faed33d", null ],
    [ "ui", "class_dlg___escala__grises.html#ab0fc1b690959ac003416309dad9232d9", null ]
];