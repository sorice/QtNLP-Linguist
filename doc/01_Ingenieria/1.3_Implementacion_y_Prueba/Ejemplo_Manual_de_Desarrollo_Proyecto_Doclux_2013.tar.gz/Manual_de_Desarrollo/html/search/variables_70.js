var searchData=
[
  ['parametros',['parametros',['../struct_comando.html#aee184567e726030def5f83a67d770d52',1,'Comando']]],
  ['procesada_5factual',['procesada_actual',['../class_main_window.html#aa8152d36de27ec34f08095e60b37fe9b',1,'MainWindow']]],
  ['procesador_5fimagen',['procesador_imagen',['../class_main_window.html#aeec943db13f5344fc9790b621dd32b72',1,'MainWindow']]]
];
