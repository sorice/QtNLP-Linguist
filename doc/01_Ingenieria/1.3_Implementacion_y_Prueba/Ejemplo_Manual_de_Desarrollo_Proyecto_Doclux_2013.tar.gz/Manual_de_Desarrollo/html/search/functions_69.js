var searchData=
[
  ['imageclicked',['imageClicked',['../class_image_thumbnail.html#a6b6cc041c5515a9614058b5697e868e6',1,'ImageThumbnail::imageClicked()'],['../class_main_window.html#a107c1a71b0aca343adf183b95a89ba91',1,'MainWindow::imageClicked()']]],
  ['imageclickedcargadas',['imageClickedCargadas',['../class_main_window.html#a740ea0c0715947ea0f2ca3125ba91e50',1,'MainWindow']]],
  ['inicializar',['inicializar',['../class_main_window.html#a5071f1b3e157d301699c8c07ce2de60c',1,'MainWindow']]],
  ['inicializar_5fescenario_5fcargadas',['inicializar_escenario_cargadas',['../class_main_window.html#aa1af7ccdcf49abb298a966074df549d9',1,'MainWindow']]],
  ['inicializar_5fescenario_5fprocesadas',['inicializar_escenario_procesadas',['../class_main_window.html#af4f906bf5df745c395f4b46ec3d008dd',1,'MainWindow']]],
  ['inicializar_5fescenarios',['inicializar_escenarios',['../class_main_window.html#a1b95563932fd4149ae5892aa40a4e3a3',1,'MainWindow']]],
  ['inicio_5fprocesamiento',['inicio_procesamiento',['../classdlbrillo.html#aa925751da32b92232c311180cce6549c',1,'dlbrillo::inicio_procesamiento()'],['../classdlcontraste.html#a339b95d7007bb25e6f43ba9a1019fda2',1,'dlcontraste::inicio_procesamiento()'],['../class_dlg___balancear__colores.html#af0e6d5c5def881ad4138ac5ae06bb6f7',1,'Dlg_Balancear_colores::inicio_procesamiento()'],['../class_dlg___escala__grises.html#a35abdbcf0b9c0bb50a9139099eb4847c',1,'Dlg_Escala_grises::inicio_procesamiento()'],['../class_dlg___escalar.html#a0982e6576a71b5fac4b6649690c43d09',1,'Dlg_Escalar::inicio_procesamiento()'],['../class_dlg___gamma.html#a2e7e80635752cbd49bf3228535f9a94d',1,'Dlg_Gamma::inicio_procesamiento()'],['../class_dlg__modificar__color.html#a3b92ea69b9e3c3896ce547e3fabb48e3',1,'Dlg_modificar_color::inicio_procesamiento()']]]
];
