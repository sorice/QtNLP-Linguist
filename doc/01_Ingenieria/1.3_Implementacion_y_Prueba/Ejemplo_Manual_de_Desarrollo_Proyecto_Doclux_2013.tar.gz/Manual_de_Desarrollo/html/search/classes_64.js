var searchData=
[
  ['dlbrillo',['dlbrillo',['../classdlbrillo.html',1,'']]],
  ['dlcontraste',['dlcontraste',['../classdlcontraste.html',1,'']]],
  ['dlg_5fbalancear_5fcolores',['Dlg_Balancear_colores',['../class_dlg___balancear__colores.html',1,'']]],
  ['dlg_5fescala_5fgrises',['Dlg_Escala_grises',['../class_dlg___escala__grises.html',1,'']]],
  ['dlg_5fescalar',['Dlg_Escalar',['../class_dlg___escalar.html',1,'']]],
  ['dlg_5fgamma',['Dlg_Gamma',['../class_dlg___gamma.html',1,'']]],
  ['dlg_5fmodificar_5fcolor',['Dlg_modificar_color',['../class_dlg__modificar__color.html',1,'']]],
  ['dlgtransformar',['DlgTransformar',['../class_dlg_transformar.html',1,'']]]
];
