var searchData=
[
  ['dlg_5fbalancear_5fcolores',['dlg_balancear_colores',['../class_main_window.html#a2153a36f870b1ffeeea0ee63fe60b0a2',1,'MainWindow']]],
  ['dlg_5fbrillo',['dlg_brillo',['../class_main_window.html#a328267e7b027ffd7581210bfd99555ea',1,'MainWindow']]],
  ['dlg_5fcontraste',['dlg_contraste',['../class_main_window.html#ac150b0b897c78c9a3722df8e7f7cdf94',1,'MainWindow']]],
  ['dlg_5fescala_5fgrises',['dlg_escala_grises',['../class_main_window.html#a4731bff04a84f82a9510164b066c9631',1,'MainWindow']]],
  ['dlg_5fescalar',['dlg_escalar',['../class_main_window.html#a413bbc661f587d5b03af93e31e487921',1,'MainWindow']]],
  ['dlg_5fgamma',['dlg_gamma',['../class_main_window.html#adc22deb89d6d0f0922e72ff8c31e57e4',1,'MainWindow']]],
  ['dlg_5fmodificar_5fcolor',['dlg_modificar_color',['../class_main_window.html#a229c3246611351d566d271b1bcc31bb0',1,'MainWindow']]],
  ['dlg_5ftransformar',['dlg_transformar',['../class_main_window.html#aa99dec2e18769835a6ddd626240788cc',1,'MainWindow']]]
];
