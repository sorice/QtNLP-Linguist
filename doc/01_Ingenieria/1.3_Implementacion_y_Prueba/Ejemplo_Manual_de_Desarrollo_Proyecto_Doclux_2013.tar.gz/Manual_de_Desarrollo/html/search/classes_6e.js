var searchData=
[
  ['nombre_5fclase',['nombre_clase',['../classnombre__clase.html',1,'']]]
];
