var searchData=
[
  ['escena',['escena',['../class_main_window.html#a2a4a240f49c741c729c922ef4aa1a871',1,'MainWindow']]],
  ['escena_5foriginal',['escena_original',['../class_main_window.html#a8de7eed3f8aab07c389472b9e50881fd',1,'MainWindow']]],
  ['escena_5fprocesada',['escena_procesada',['../class_main_window.html#aca15073a1c0c7e2f7eda6a9f4794b6b4',1,'MainWindow']]]
];
