var searchData=
[
  ['balancear_5fc',['balancear_c',['../class_main_window.html#a7d2b46028d8ed404d4b0db2c48731f6f',1,'MainWindow']]],
  ['balancear_5fcolores',['balancear_colores',['../class_main_window.html#afdde8ef9f4a9fd3e71049b763dac128e',1,'MainWindow']]],
  ['brillo',['brillo',['../class_main_window.html#a86c3dc629b80b2b2677d396a5e218f1c',1,'MainWindow']]],
  ['brillo_5fa',['brillo_a',['../class_main_window.html#a2257f6a5dc694cbe9d8ee6a07351f50f',1,'MainWindow']]],
  ['brillo_5fautomatico',['brillo_automatico',['../class_main_window.html#a1236554ea7b0b5443d2cfd0cc52c09b8',1,'MainWindow']]],
  ['brillo_5fimagen',['brillo_imagen',['../class_main_window.html#a41bf52a0cd5f72494c9177b68c65eb3e',1,'MainWindow']]]
];
