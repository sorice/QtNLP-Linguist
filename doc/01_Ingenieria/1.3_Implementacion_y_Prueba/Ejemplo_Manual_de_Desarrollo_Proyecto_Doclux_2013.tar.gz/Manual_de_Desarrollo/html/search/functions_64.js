var searchData=
[
  ['deshabilitar_5ffiltros',['deshabilitar_filtros',['../class_main_window.html#a7b89525eaf44a6ee5c0dde9c8a0aba8a',1,'MainWindow']]],
  ['deshacer',['deshacer',['../class_lista_de_comandos.html#a58142e5a378f60439765f322af306b87',1,'ListaDeComandos']]]
];
