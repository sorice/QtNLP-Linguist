var searchData=
[
  ['habilitar_5faplicar_5ftodas',['habilitar_aplicar_todas',['../class_main_window.html#a9e8391527bedb2c4fec2ad4e60e33206',1,'MainWindow']]],
  ['habilitar_5fbtn_5fgestionar_5fimagenes',['Habilitar_btn_Gestionar_imagenes',['../class_main_window.html#a240f659c5989fd69a00216e9d415e1cd',1,'MainWindow']]],
  ['habilitar_5ffiltros',['habilitar_filtros',['../class_main_window.html#ad92830c231e7c7a45ca572937a5eab54',1,'MainWindow']]]
];
