var searchData=
[
  ['limpiar',['limpiar',['../class_lista_de_comandos.html#ad3aca37989727a3e293abe0fcc79b13c',1,'ListaDeComandos']]],
  ['limpiar_5flista_5fcomandos',['limpiar_lista_comandos',['../class_lista_de_comandos.html#a89a9fd5f0657fdc8a047e163710dee2b',1,'ListaDeComandos']]],
  ['limpiar_5flista_5fdeshacer_5frehacer',['limpiar_lista_deshacer_rehacer',['../class_lista_de_comandos.html#ad3996f153c09c099caec3e562def16ca',1,'ListaDeComandos']]],
  ['limpiar_5flistas',['limpiar_listas',['../class_lista_de_comandos.html#a573ca21d7c32e701c95181800c3dd684',1,'ListaDeComandos']]],
  ['limpiar_5fvisor_5foriginal',['limpiar_visor_original',['../class_main_window.html#a1871226e1fa5d73eb6a66444de90bd21',1,'MainWindow']]],
  ['limpiar_5fvisores',['limpiar_visores',['../class_main_window.html#a75e62da234c0b8d250a32f30e254b468',1,'MainWindow']]]
];
