var searchData=
[
  ['verificar_5fmarcadas',['Verificar_marcadas',['../class_main_window.html#a62b925c0022e77732392df30955b2226',1,'MainWindow']]],
  ['verificar_5fseleccionadas',['verificar_seleccionadas',['../class_main_window.html#a1eb2f9e856953f652ec90660e28a48d7',1,'MainWindow']]]
];
