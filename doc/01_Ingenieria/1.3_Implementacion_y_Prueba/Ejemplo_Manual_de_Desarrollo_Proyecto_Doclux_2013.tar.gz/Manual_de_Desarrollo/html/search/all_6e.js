var searchData=
[
  ['nueva_5fimagen_5fcargada',['nueva_imagen_cargada',['../class_main_window.html#a73ce9a190bd05f978020e7cf5c6707eb',1,'MainWindow']]],
  ['nuevo_5fcomando',['nuevo_comando',['../class_lista_de_comandos.html#a88f98d5081569102cacb96bfdedd2d8b',1,'ListaDeComandos']]]
];
