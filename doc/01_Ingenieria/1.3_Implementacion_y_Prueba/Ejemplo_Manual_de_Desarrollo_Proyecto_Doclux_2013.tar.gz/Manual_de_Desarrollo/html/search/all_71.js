var searchData=
[
  ['qimage_5fto_5fmagick_5fimage',['qimage_to_magick_image',['../filtros_8cpp.html#a05fc4cc46a649e692af4c869c58e0ed0',1,'filtros.cpp']]]
];
