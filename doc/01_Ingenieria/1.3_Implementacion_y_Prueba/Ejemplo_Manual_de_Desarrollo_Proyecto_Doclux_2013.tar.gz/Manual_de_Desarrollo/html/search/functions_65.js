var searchData=
[
  ['emitir_5fbalancear_5fcolores',['emitir_balancear_colores',['../class_main_window.html#a490837bafbd3b44835935f1da4ba19c4',1,'MainWindow']]],
  ['emitir_5fbrillo',['emitir_brillo',['../class_main_window.html#a84d81485852930654d8036da3cf07357',1,'MainWindow']]],
  ['emitir_5fbrillo_5fautomatico',['emitir_brillo_automatico',['../class_main_window.html#a1c3024a64533582afb2e41f4902a43b0',1,'MainWindow']]],
  ['emitir_5fcontraste',['emitir_contraste',['../class_main_window.html#a82fd154220d59a04e1877a4c4d651e6c',1,'MainWindow']]],
  ['emitir_5fcontraste_5fautomatico',['emitir_contraste_automatico',['../class_main_window.html#ab57165b12e64e8d07811d6b149383050',1,'MainWindow']]],
  ['emitir_5fescala_5fgrises',['emitir_escala_grises',['../class_main_window.html#ae931f3b7a29c8029d2a581b0db3eb922',1,'MainWindow']]],
  ['emitir_5fescalar',['emitir_escalar',['../class_main_window.html#af99eaeaba80f1658c5ae04dfbb843e8a',1,'MainWindow']]],
  ['emitir_5fgamma',['emitir_gamma',['../class_main_window.html#a496c46d286c0d78da312bdd6c1692466',1,'MainWindow']]],
  ['emitir_5fmodificar_5fcolor',['emitir_modificar_color',['../class_main_window.html#a378f6a033f9f0fcf7f428da23429f1ca',1,'MainWindow']]],
  ['esc_5fgrises',['esc_grises',['../class_main_window.html#a438c639fcbefd48b7e1b595059a177be',1,'MainWindow']]],
  ['escala_5fg',['escala_g',['../class_main_window.html#ad9dc8a312839aa355534909ab37406a1',1,'MainWindow']]],
  ['escala_5fgrises',['escala_grises',['../filtros_8cpp.html#adde4871b5554bbb701cd002e93e10d78',1,'filtros.cpp']]],
  ['escalar',['escalar',['../class_main_window.html#ae78541fd512b5f9ed2ae64a408762c14',1,'MainWindow']]],
  ['escalar_5fim',['escalar_im',['../class_main_window.html#aad0e44739239d593ef11b9847c6b51c2',1,'MainWindow']]],
  ['escalar_5fimagen',['escalar_imagen',['../class_main_window.html#a8fbf6a9440076bb6f795aa69797614d6',1,'MainWindow']]]
];
