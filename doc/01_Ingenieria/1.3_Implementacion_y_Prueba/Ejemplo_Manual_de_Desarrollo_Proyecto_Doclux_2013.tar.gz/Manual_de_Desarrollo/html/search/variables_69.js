var searchData=
[
  ['img',['img',['../class_main_window.html#af0c040898bdbcb0dad17c16e5ae0fea2',1,'MainWindow']]],
  ['item',['item',['../class_main_window.html#a0fa41d720dcb7d5e2628ee91d43fa926',1,'MainWindow']]]
];
