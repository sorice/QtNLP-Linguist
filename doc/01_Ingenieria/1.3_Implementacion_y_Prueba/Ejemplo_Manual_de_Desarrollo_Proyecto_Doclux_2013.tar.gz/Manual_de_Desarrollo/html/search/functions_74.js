var searchData=
[
  ['thumbselected',['thumbSelected',['../class_main_window.html#a28977675bdfab2322cb3c7384517271b',1,'MainWindow']]],
  ['thumbselectedcargadas',['thumbSelectedCargadas',['../class_main_window.html#a9778d59e3d5b84e2a10b26f334162410',1,'MainWindow']]]
];
