var searchData=
[
  ['original_5factual',['original_actual',['../class_main_window.html#a70e83c58b7a6bb2b832e3336b4992c01',1,'MainWindow']]]
];
