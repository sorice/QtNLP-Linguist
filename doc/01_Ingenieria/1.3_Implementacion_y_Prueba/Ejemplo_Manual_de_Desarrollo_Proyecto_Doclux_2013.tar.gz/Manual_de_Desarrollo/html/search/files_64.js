var searchData=
[
  ['dlbrillo_2eh',['dlbrillo.h',['../dlbrillo_8h.html',1,'']]],
  ['dlcontraste_2eh',['dlcontraste.h',['../dlcontraste_8h.html',1,'']]],
  ['dlg_5fbalancear_5fcolores_2eh',['dlg_balancear_colores.h',['../dlg__balancear__colores_8h.html',1,'']]],
  ['dlg_5fescala_5fgrises_2eh',['dlg_escala_grises.h',['../dlg__escala__grises_8h.html',1,'']]],
  ['dlg_5fescalar_2eh',['dlg_escalar.h',['../dlg__escalar_8h.html',1,'']]],
  ['dlg_5fgamma_2eh',['dlg_gamma.h',['../dlg__gamma_8h.html',1,'']]],
  ['dlg_5fmodificar_5fcolor_2eh',['dlg_modificar_color.h',['../dlg__modificar__color_8h.html',1,'']]],
  ['dlgtransformar_2eh',['dlgtransformar.h',['../dlgtransformar_8h.html',1,'']]]
];
