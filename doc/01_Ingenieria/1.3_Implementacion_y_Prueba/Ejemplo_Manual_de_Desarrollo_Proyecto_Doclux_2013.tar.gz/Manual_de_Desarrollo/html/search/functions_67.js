var searchData=
[
  ['gamma',['gamma',['../class_main_window.html#ad49c964aa3b8267d2ebc8cf7b003960c',1,'MainWindow']]],
  ['gamma_5fimagen',['gamma_imagen',['../class_main_window.html#a02c66f0d0eee87288e86804138e51b4c',1,'MainWindow']]],
  ['generar_5fimagen',['generar_imagen',['../class_main_window.html#a007d5ee2ce9563a54c1a3977d9c7c078',1,'MainWindow']]],
  ['get_5flista_5fcomandos',['get_lista_comandos',['../class_lista_de_comandos.html#a2426bb0c336b8a2054de70bc29597454',1,'ListaDeComandos']]],
  ['get_5fvisor',['get_visor',['../class_main_window.html#a63f562825711f4cf1ac526a270d7a98c',1,'MainWindow']]]
];
