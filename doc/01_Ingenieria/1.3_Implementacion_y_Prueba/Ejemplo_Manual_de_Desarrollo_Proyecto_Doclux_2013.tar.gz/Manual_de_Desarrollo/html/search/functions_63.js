var searchData=
[
  ['cargar_5ffiltros',['cargar_filtros',['../class_main_window.html#a528b3b8acfaae987eb6d1ccf762cc4d9',1,'MainWindow']]],
  ['comando',['Comando',['../struct_comando.html#a604b29b29f590c08b7f6ef5121e39fa8',1,'Comando']]],
  ['contraste',['contraste',['../class_main_window.html#aa0c61afc8f5900630ec9e16da92a4f0f',1,'MainWindow']]],
  ['contraste_5fa',['contraste_a',['../class_main_window.html#a59cc5d480a8c166bdcc49ebbd32b3b7e',1,'MainWindow']]],
  ['contraste_5fautomatico',['contraste_automatico',['../class_main_window.html#a0ae43a795cef002ae9fe14a695c39452',1,'MainWindow']]],
  ['contraste_5fimagen',['contraste_imagen',['../class_main_window.html#aadb974453ffc0d6c4a2bd54287544249',1,'MainWindow']]]
];
