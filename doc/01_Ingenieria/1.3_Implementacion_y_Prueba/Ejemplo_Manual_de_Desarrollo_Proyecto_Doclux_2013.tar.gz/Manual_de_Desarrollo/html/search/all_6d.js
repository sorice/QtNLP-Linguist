var searchData=
[
  ['m_5fpath',['m_path',['../class_image_thumbnail.html#aa7e96648415bb76d7686b853b95b3e10',1,'ImageThumbnail']]],
  ['magick_5fimage_5fto_5fqimage',['magick_image_to_qimage',['../filtros_8cpp.html#a9931aee68ae199a86360d6f308674ec6',1,'filtros.cpp']]],
  ['mainwindow',['MainWindow',['../class_main_window.html',1,'']]],
  ['mainwindow_2eh',['mainwindow.h',['../mainwindow_8h.html',1,'']]],
  ['marca_5fagua',['marca_agua',['../filtros_8cpp.html#a224be8c6d5f25956b1027f3ab61332ef',1,'filtros.cpp']]],
  ['modificar_5fc',['modificar_c',['../class_main_window.html#a249a8672a166ae6996bc04cf7c8e3d9e',1,'MainWindow']]],
  ['modificar_5fcolor',['modificar_color',['../class_main_window.html#a457b81d1ec388eb580a50c3fbb40f2b3',1,'MainWindow']]],
  ['modifycolor',['ModifyColor',['../filtros_8cpp.html#a9058ac919791780f63925956a649330b',1,'filtros.cpp']]],
  ['mostrar_5fimagen',['mostrar_imagen',['../class_main_window.html#a469f5374bf0fa8758015ec1abd04d0c0',1,'MainWindow']]],
  ['mostrar_5fimagen_5foriginal',['mostrar_imagen_original',['../class_main_window.html#a73af02f0d80fcb5013e1df796aab77d8',1,'MainWindow']]],
  ['mostrar_5fimagen_5fprocesada',['mostrar_imagen_procesada',['../class_main_window.html#a329bb83239eb0e59598c2b7588a64dea',1,'MainWindow::mostrar_imagen_procesada()'],['../class_main_window.html#a60d4d04ef8eb25456dcd5b28b1b3ccf2',1,'MainWindow::mostrar_imagen_procesada(QString src)']]],
  ['movie',['movie',['../class_cargando.html#ad397d2285237cb92fdd1c4a74e86bbe5',1,'Cargando']]]
];
