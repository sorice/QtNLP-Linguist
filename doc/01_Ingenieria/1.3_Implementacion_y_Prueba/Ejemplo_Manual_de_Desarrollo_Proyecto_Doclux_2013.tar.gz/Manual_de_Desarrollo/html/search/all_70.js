var searchData=
[
  ['parametros',['parametros',['../struct_comando.html#aee184567e726030def5f83a67d770d52',1,'Comando']]],
  ['procesada_5factual',['procesada_actual',['../class_main_window.html#aa8152d36de27ec34f08095e60b37fe9b',1,'MainWindow']]],
  ['procesador_5fimagen',['procesador_imagen',['../class_main_window.html#aeec943db13f5344fc9790b621dd32b72',1,'MainWindow']]],
  ['procesamiento_5fterminado',['procesamiento_terminado',['../class_main_window.html#a156b1349c216418ae2e5feca9dcdf3b2',1,'MainWindow']]],
  ['procesando',['procesando',['../class_main_window.html#aad6efc8724c36b968ca720ebf72681e2',1,'MainWindow']]],
  ['puede_5fdeshacer',['puede_deshacer',['../class_lista_de_comandos.html#aa0526072a7c33fdc9f3464cf7e1e2763',1,'ListaDeComandos']]],
  ['puede_5frehacer',['puede_rehacer',['../class_lista_de_comandos.html#a10b94f2bf150380a5b368a343e23e25b',1,'ListaDeComandos']]]
];
