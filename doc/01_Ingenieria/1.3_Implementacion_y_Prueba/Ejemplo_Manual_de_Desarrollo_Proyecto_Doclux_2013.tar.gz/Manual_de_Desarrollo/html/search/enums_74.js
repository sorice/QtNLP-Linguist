var searchData=
[
  ['tipo_5fcomando',['TIPO_COMANDO',['../listadecomandos_8h.html#ae669d6dc371343a742755d00f0650a2d',1,'listadecomandos.h']]]
];
