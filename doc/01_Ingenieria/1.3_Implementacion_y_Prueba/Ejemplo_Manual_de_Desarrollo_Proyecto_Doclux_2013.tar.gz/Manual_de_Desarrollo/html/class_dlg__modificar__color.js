var class_dlg__modificar__color =
[
    [ "Dlg_modificar_color", "class_dlg__modificar__color.html#a16c9648fc5f178a7f6057c0e0941028e", null ],
    [ "~Dlg_modificar_color", "class_dlg__modificar__color.html#ab067c4869b28f3bc7ff5b2824b455932", null ],
    [ "closeEvent", "class_dlg__modificar__color.html#a1d04b3b3ad132bedfeb6e8e948a109dc", null ],
    [ "fin_procesamiento", "class_dlg__modificar__color.html#a5f1f6b4ab262559f2b9294c780cbc1ec", null ],
    [ "inicio_procesamiento", "class_dlg__modificar__color.html#a3b92ea69b9e3c3896ce547e3fabb48e3", null ],
    [ "on_btn_todas_clicked", "class_dlg__modificar__color.html#ab322c9cb5c65a7cc7d8326e905e63eee", null ],
    [ "on_pushButton_clicked", "class_dlg__modificar__color.html#ad812889335c5abeb2d8c616a908efbc2", null ],
    [ "ui", "class_dlg__modificar__color.html#a8cd59b6fdcd9c5aee58fca9dbf37d1e3", null ]
];