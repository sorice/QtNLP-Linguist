var files =
[
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/cargando.h", "cargando_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlbrillo.h", "dlbrillo_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlcontraste.h", "dlcontraste_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlg_balancear_colores.h", "dlg__balancear__colores_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlg_escala_grises.h", "dlg__escala__grises_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlg_escalar.h", "dlg__escalar_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlg_gamma.h", "dlg__gamma_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlg_modificar_color.h", "dlg__modificar__color_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/dlgtransformar.h", "dlgtransformar_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/filtros.cpp", "filtros_8cpp.html", "filtros_8cpp" ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/imagethumbnail.h", "imagethumbnail_8h.html", null ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/listadecomandos.h", "listadecomandos_8h.html", "listadecomandos_8h" ],
    [ "/media/datos/WORK/repository/testing_cpp/trunk/DocLuxDemo/mainwindow.h", "mainwindow_8h.html", null ]
];