var classdlcontraste =
[
    [ "dlcontraste", "classdlcontraste.html#a5eb6ebb31af246ef757b915862630268", null ],
    [ "~dlcontraste", "classdlcontraste.html#ac1f1dbad901b7ca36d32438b7ef1f9c9", null ],
    [ "closeEvent", "classdlcontraste.html#a584a7e33035919709b2a539b7dd66bee", null ],
    [ "fin_procesamiento", "classdlcontraste.html#aa60ca4c4b59f4cecd34a6b871da890fc", null ],
    [ "inicio_procesamiento", "classdlcontraste.html#a339b95d7007bb25e6f43ba9a1019fda2", null ],
    [ "on_automatico_clicked", "classdlcontraste.html#a3b53e59a28c23f54f3aad39ce350fbaf", null ],
    [ "on_btn_actual_clicked", "classdlcontraste.html#a7287985dea4d538cdd65e959340a0e1f", null ],
    [ "on_btn_todas_clicked", "classdlcontraste.html#a0ef1635b9e822ed7bf1df35f9a115e05", null ],
    [ "on_manual_clicked", "classdlcontraste.html#a92e82e1a24193f6b0e8570ca0c79503a", null ],
    [ "ui", "classdlcontraste.html#a5363f67297d0c287d4001229c034f379", null ]
];