var class_lista_de_comandos =
[
    [ "ListaDeComandos", "class_lista_de_comandos.html#a66c943feea3a442a457f18ee8d9fa939", null ],
    [ "~ListaDeComandos", "class_lista_de_comandos.html#af8a007ef0e69089cff0f2032fe806fc3", null ],
    [ "deshacer", "class_lista_de_comandos.html#a58142e5a378f60439765f322af306b87", null ],
    [ "get_lista_comandos", "class_lista_de_comandos.html#a2426bb0c336b8a2054de70bc29597454", null ],
    [ "limpiar", "class_lista_de_comandos.html#ad3aca37989727a3e293abe0fcc79b13c", null ],
    [ "limpiar_lista_comandos", "class_lista_de_comandos.html#a89a9fd5f0657fdc8a047e163710dee2b", null ],
    [ "limpiar_lista_deshacer_rehacer", "class_lista_de_comandos.html#ad3996f153c09c099caec3e562def16ca", null ],
    [ "limpiar_listas", "class_lista_de_comandos.html#a573ca21d7c32e701c95181800c3dd684", null ],
    [ "nuevo_comando", "class_lista_de_comandos.html#a88f98d5081569102cacb96bfdedd2d8b", null ],
    [ "puede_deshacer", "class_lista_de_comandos.html#aa0526072a7c33fdc9f3464cf7e1e2763", null ],
    [ "puede_rehacer", "class_lista_de_comandos.html#a10b94f2bf150380a5b368a343e23e25b", null ],
    [ "rehacer", "class_lista_de_comandos.html#aff0154ef0cf8a2189cd77e8eca7f4308", null ],
    [ "rehacer_comando", "class_lista_de_comandos.html#a4013257e7c70518a259e5997475ee05d", null ],
    [ "listaComandos", "class_lista_de_comandos.html#ad1bb5ecdce44b8d341ddedae8c30a8a4", null ],
    [ "listaDeshacerRehacer", "class_lista_de_comandos.html#a54c2ccfd7e255a439ccd93686340c035", null ]
];