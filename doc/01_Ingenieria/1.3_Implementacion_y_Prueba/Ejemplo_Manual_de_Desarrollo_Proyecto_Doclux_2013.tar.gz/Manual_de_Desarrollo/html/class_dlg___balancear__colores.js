var class_dlg___balancear__colores =
[
    [ "Dlg_Balancear_colores", "class_dlg___balancear__colores.html#a94542b37996cbae76718b58c6a682692", null ],
    [ "~Dlg_Balancear_colores", "class_dlg___balancear__colores.html#a79b07d0c55bd22d724bba5217c9dd1fb", null ],
    [ "closeEvent", "class_dlg___balancear__colores.html#a12c9768a6172280215950529620aae47", null ],
    [ "fin_procesamiento", "class_dlg___balancear__colores.html#a973370efb7ec66076f42b19d41b06e65", null ],
    [ "inicio_procesamiento", "class_dlg___balancear__colores.html#af0e6d5c5def881ad4138ac5ae06bb6f7", null ],
    [ "on_btn_todas_clicked", "class_dlg___balancear__colores.html#a46e541c60548bd490acffd101befb513", null ],
    [ "on_pushButton_3_clicked", "class_dlg___balancear__colores.html#ad8fb6d731d1bea3f081176f9270e8ea6", null ],
    [ "ui", "class_dlg___balancear__colores.html#a831b609428df02aae10339d694c007ee", null ]
];